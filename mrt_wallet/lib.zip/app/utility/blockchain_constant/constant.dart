class BlockchainConstant {
  static const int maxBip32LevelIndex = 5;
  static const int maxByronLegacyBip32LevelIndex = 2;
}
