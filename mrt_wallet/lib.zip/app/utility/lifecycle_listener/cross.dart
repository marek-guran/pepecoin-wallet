import 'package:mrt_wallet/types/typedef.dart';
import 'core.dart';

AppLifecycleListener platformLifeCycel(
        DynamicVoid onHide, DynamicVoid onFocus) =>
    throw UnsupportedError(
        'Cannot create a instance without dart:html or dart:io.');
