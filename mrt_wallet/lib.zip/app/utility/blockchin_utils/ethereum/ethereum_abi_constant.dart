import 'package:on_chain/on_chain.dart';

class ETHAbiConstant {
  static final AbiFunctionFragment erc20Decimal =
      AbiFunctionFragment.fromJson(const {
    "inputs": [],
    "name": "decimals",
    "outputs": [
      {"internalType": "uint8", "name": "", "type": "uint8"}
    ],
    "stateMutability": "view",
    "type": "function"
  }, false);
  static final AbiFunctionFragment erc20Balance =
      AbiFunctionFragment.fromJson(const {
    "inputs": [
      {"internalType": "address", "name": "account", "type": "address"}
    ],
    "name": "balanceOf",
    "outputs": [
      {"internalType": "uint256", "name": "", "type": "uint256"}
    ],
    "stateMutability": "view",
    "type": "function"
  }, false);
  static final AbiFunctionFragment erc20Symbol =
      AbiFunctionFragment.fromJson(const {
    "inputs": [],
    "name": "symbol",
    "outputs": [
      {"internalType": "string", "name": "", "type": "string"}
    ],
    "stateMutability": "view",
    "type": "function"
  }, false);
  static final AbiFunctionFragment erc20Transfer =
      AbiFunctionFragment.fromJson(const {
    "inputs": [
      {"internalType": "address", "name": "to", "type": "address"},
      {"internalType": "uint256", "name": "value", "type": "uint256"}
    ],
    "name": "transfer",
    "outputs": [
      {"internalType": "bool", "name": "", "type": "bool"}
    ],
    "stateMutability": "nonpayable",
    "type": "function"
  }, false);
}
