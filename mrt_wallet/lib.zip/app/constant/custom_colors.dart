import 'package:flutter/material.dart';

class CustomColors {
  const CustomColors._();

  static const Color green = Colors.green;
  static const Color blue = Colors.blue;
}
