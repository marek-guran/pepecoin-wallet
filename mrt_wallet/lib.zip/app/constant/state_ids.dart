class StateIdsConst {
  static const String main = "main";
  static const String bitcoin = "bitcoin";
}
