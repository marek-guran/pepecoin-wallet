import 'package:mrt_wallet/app/websocket/core/core.dart';

Future<PlatformWebScoket> connectSoc(String url, {List<String>? protocols}) =>
    throw UnsupportedError(
        'Cannot create a instance without dart:html or dart:io.');
