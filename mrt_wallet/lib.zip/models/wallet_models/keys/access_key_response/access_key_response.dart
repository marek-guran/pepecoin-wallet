abstract class AccessKeyResponse {}
