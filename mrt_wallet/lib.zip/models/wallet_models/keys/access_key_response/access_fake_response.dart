import 'access_key_response.dart';

class AccessFakeResponse implements AccessKeyResponse {}
