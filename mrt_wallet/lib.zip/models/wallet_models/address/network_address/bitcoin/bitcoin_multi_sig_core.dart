import 'package:mrt_wallet/models/wallet_models/address/network_address/bitcoin/multisig_address_details.dart';

mixin BitcoinMultiSigBase {
  abstract final BitcoinMultiSignatureAddress multiSignatureAddress;
}
